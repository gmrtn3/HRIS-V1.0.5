<?php
namespace BiometricsData;

require 'CompanyInfo.php';
require 'Employee.php';
require 'Records.php';
